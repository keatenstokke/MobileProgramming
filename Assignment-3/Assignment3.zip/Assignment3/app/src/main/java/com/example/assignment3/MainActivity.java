package com.example.assignment3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import android.widget.Toast;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import android.util.Log;

// Main activity implements the OnMapReadyCallback and OnMarkerClickListener
public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    // Projection for the content provider
    String [] picturesDB = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_TITLE,
            ToDoProvider.TODO_TABLE_COL_LATITUDE,
            ToDoProvider.TODO_TABLE_COL_LONGITUDE,
            ToDoProvider.TODO_TABLE_COL_PATH,
            ToDoProvider.TODO_TABLE_COL_DATE
    };

    // Variable for the current date in string form
    private String currentDate2;

    // Variable for the title of the picture/image
    private String imgTitle;

    // Variable for the GoogleMap Object
    private GoogleMap mMap;

    // Variable that handles requesting the current location
    private LocationRequest locationRequest;

    // Variable that handles the current locations callback function
    private LocationCallback locationCallback;

    // Variable for the current locations "request code"
    private int locationRequestCode = 1000;

    // Variable for the current location to "Request a photo"
    private static final int REQUEST_TAKE_PHOTO = 100;

    // Variable for the latitude of the current location
    private double latData = 0.0;

    // Variable for the longitude of the current location
    private double longData = 0.0;

    // Variable for the camera button in the main activity
    private Button cameraButton;

    // Variable for the file path of the photo when an image is taken
    String currentPhotoPath = null;

    // Variable that handles the current location
    private FusedLocationProviderClient mFusedLocationClient;

    // Standard on create method for the activity
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        // Link the map fragment to the current activity asynchronously
        mapFragment.getMapAsync(MainActivity.this);

        // Uses the location services to get the current location for this activity
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Creates a new location request to get the current location
        locationRequest = LocationRequest.create();

        // Sets the priority for the location request
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        // Sets the interval for how often the current location is obtained
        locationRequest.setInterval(20 * 1000);

        // Callback function to get the current location
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult){
                if(locationResult == null){
                    return;
                }
                for(Location location : locationResult.getLocations()){
                    if (location != null){
                        // If available, set the latitude and longitude
                        latData = location.getLatitude();
                        longData = location.getLongitude();
                    }
                }
            }
        };

        // Checks the permission for the current location
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            // If the location permission is not yet granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, locationRequestCode);

        }else{
            // If the location permission is already granted
            mFusedLocationClient.getLastLocation().addOnSuccessListener(MainActivity.this, location -> {
                if(location != null){
                    // If available, set the latitude and longitude
                    latData = location.getLatitude();
                    longData = location.getLongitude();
                }else{
                    mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                }
            });
        }

        // Link the local camera Button variable to the actual Button in the activity_main.xml file
        cameraButton = (Button) findViewById(R.id.cameraBtn);
        // Listen for when the camera button is pressed
        // If the camera button was pressed, display a toast that notifies the user the camera is opening, then open the camera
        cameraButton.setOnClickListener(v -> {
            dispatchTakePictureIntent(v);
        });
    }

    // TODO: Add additional comments here...
    @Override
    public void onMapReady(GoogleMap googleMap){
        mMap = googleMap;

        Cursor myCursor = getContentResolver().query(ToDoProvider.CONTENT_URI, picturesDB,null,null, null);

        if(myCursor != null & myCursor.getCount() > 0){

            for(int i = 0; i <  myCursor.getCount(); i++){
                myCursor.moveToNext();
                // Get the note ID (int) of the latest note (column 0)
                int newestLat = myCursor.getInt(2);
                int newestLong = myCursor.getInt(3);

                // Get the note title (string) of the latest note (column 1)
                String newestTitle = myCursor.getString(1);
                LatLng currentPic = new LatLng(newestLat, newestLong);
                mMap.addMarker(new MarkerOptions().position(currentPic).title(newestTitle));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(currentPic));
                mMap.setOnMarkerClickListener(marker -> {
                    String name = marker.getTitle();
                    Intent intent = new Intent(MainActivity.this, DisplayImage.class);
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    intent.putExtra("picture", false);
                    intent.putExtra("path", currentPhotoPath);
                    startActivity(intent);
                    return false;
                });
            }
        }

    }

    // If the permissions for the camera have not been granted, ask the user for permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    mFusedLocationClient.getLastLocation().addOnSuccessListener(MainActivity.this, location -> {
                        if(location != null){
                            // If available, set the current latitude and longitude
                            latData = location.getLatitude();
                            longData = location.getLongitude();
                        }else{
                            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                        }
                    });
                }else{
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

    // Class for saving the image
    private File createImageFile() throws IOException{
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        // Get the current time and date of when the image was taken
        Date currentDate1 = Calendar.getInstance().getTime();

        // Save the date/time data to a string
        currentDate2 = currentDate1.toString();

        // Create a title for the image based on its attirubutes
        String currentLocation = "jpg_" + "_Latitude_" + latData + "_Longitude_" + longData + "_";
        String imageFileName = currentLocation + "Time_" + timeStamp + "_Other" + "_";
        imgTitle = imageFileName;

        // Save the image to a directory
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();

        // Return the image value
        return image;
    }

    // Class that handles opening the camera view
    private void dispatchTakePictureIntent(View v){
        // Save the intent of the picture that was taken with the camera
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        // Grant URI permissions for the intent if a picture was taken
        takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        // Ensure that there's a camera activity to handle the intent
        if(takePictureIntent.resolveActivity(getPackageManager()) != null){
            // Create the File where the photo should go
            File photoFile = null;
            try{
                photoFile = createImageFile();
            }catch(IOException ex){
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if(photoFile != null){
                takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                Uri photoURI = FileProvider.getUriForFile(this, "com.example.android.fileprovider", photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    // When the MainActivity is resumed, get the results from the image that was taken
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        // Checks to verify that an image was taken when the camera was opened
        if(requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK){

            // If a picture was taken with the camera, push the data to the ContentProvider
            ContentValues myCV = new ContentValues();
            myCV.put(ToDoProvider.TODO_TABLE_COL_TITLE, imgTitle);
            myCV.put(ToDoProvider.TODO_TABLE_COL_LATITUDE, latData);
            myCV.put(ToDoProvider.TODO_TABLE_COL_LONGITUDE, longData);
            myCV.put(ToDoProvider.TODO_TABLE_COL_PATH, currentPhotoPath);
            myCV.put(ToDoProvider.TODO_TABLE_COL_DATE, currentDate2);
            getContentResolver().insert(ToDoProvider.CONTENT_URI, myCV);
            // Place a marker on the map
            placeMarker(mMap);

            // Update the map fragment
            onMapReady(mMap);
        }
    }

    // Function that places a marker on the Google Map fragment when a picture has been taken
    public void placeMarker(GoogleMap googleMap){
        // Sets the Google Map object
        mMap = googleMap;

        // Sets the current latitude and longitude of the current location if a photo was taken
        LatLng newPicture = new LatLng(latData, longData);

        // Adds a marker to the Google Maps Fragment with the image title
        mMap.addMarker(new MarkerOptions().position(newPicture).title(imgTitle));

        // Sets the camera of the fragment to the marker that was just placed
        mMap.moveCamera(CameraUpdateFactory.newLatLng(newPicture));
    }

    // On resume function ***UNUSED***
    @Override
    protected void onResume(){
        super.onResume();
    }

    // Unused function for clicking a Google Maps Marker
    @Override
    public boolean onMarkerClick(Marker marker){
        return false;
    }
}
