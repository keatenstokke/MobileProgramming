package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

// Activity that displays the image when a marker is clicked on
public class DisplayImage extends AppCompatActivity{

    // Variable for the ImageView in the second activity to display the image
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_image);

        // Set the image view in the second activity
        imageView = findViewById(R.id.imageViewScreen);

        // Get the intent that was passed from the MainActivity
        Intent intent = getIntent();

        // Get the file path (name of the marker/title of the picture) from the intent and set that as the file path of the image for the marker
        String filePath = intent.getStringExtra("path");

        // Set the image view in the second activity to the image of the file path/marker that was passed from the MainActivity
        imageView.setImageBitmap(BitmapFactory.decodeFile(filePath));



    }
}
