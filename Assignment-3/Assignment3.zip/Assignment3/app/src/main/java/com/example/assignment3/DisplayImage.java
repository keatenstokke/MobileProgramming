package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

// Activity that displays the image when a marker is clicked on
public class DisplayImage extends AppCompatActivity{

    // Variable for the ImageView in the second activity to display the image
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_image);

        // TODO: Add comments here...
        imageView = findViewById(R.id.imageViewScreen);
        Intent intent = getIntent();
        final Boolean pictureStatus = intent.getBooleanExtra("picture", true);
        String filePath = intent.getStringExtra("path");
        imageView.setImageBitmap(BitmapFactory.decodeFile(filePath));



    }
}
