package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;

public class SortActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] UserData = new String[]{
            InfoProvider.TODO_TABLE_COL_ID, InfoProvider.TODO_TABLE_COL_FIRST_NAME, InfoProvider.TODO_TABLE_COL_MIDDLE_NAME,
            InfoProvider.TODO_TABLE_COL_LAST_NAME, InfoProvider.TODO_TABLE_COL_EMAIL, InfoProvider.TODO_TABLE_COL_PHONE_NUMBER,
            InfoProvider.TODO_TABLE_COL_ADDRESS, InfoProvider.TODO_TABLE_COL_CITY, InfoProvider.TODO_TABLE_COL_STATE,
            InfoProvider.TODO_TABLE_COL_ZIPCODE, InfoProvider.TODO_TABLE_COL_EMERGENCY_NAME,
            InfoProvider.TODO_TABLE_COL_EMERGENCY_NUMBER, InfoProvider.TODO_TABLE_COL_EMERGENCY_ADDRESS,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL, InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_LOCATION,
            InfoProvider.TODO_TABLE_COL_BIRTH_MONTH, InfoProvider.TODO_TABLE_COL_BIRTH_DAY,
            InfoProvider.TODO_TABLE_COL_BIRTH_YEAR, InfoProvider.TODO_TABLE_COL_EMERGENCY_RELATION,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_GPA, InfoProvider.TODO_TABLE_COL_ACT_SCORE,
            InfoProvider.TODO_TABLE_COL_SAT_SCORE, InfoProvider.TODO_TABLE_COL_CLASS, InfoProvider.TODO_TABLE_COL_COLLEGE_GPA,
            InfoProvider.TODO_TABLE_COL_MAJOR, InfoProvider.TODO_TABLE_COL_COLLEGE, InfoProvider.TODO_TABLE_COL_SORORITY_ONE,
            InfoProvider.TODO_TABLE_COL_SORORITY_TWO, InfoProvider.TODO_TABLE_COL_SORORITY_THREE,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_ONE, InfoProvider.TODO_TABLE_COL_ACTIVITY_TWO,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_THREE
    };

    // Creates local String variables for all the selected spinner values
    private String monthSelection, daySelection, yearSelection, relationSelection, highGPASelection, actSelection,
            satSelection, classSelection, collegeGPASelection, majorSelection, collegeSelection, firstPrefSelection,
            secondPrefSelection, thirdPrefSelection, activityOneSelection, activityTwoSelection, activityThreeSelection,
            firstName, middleName, lastName, eMail, phoneNumber, address, city, state, zipCode, emergencyName, emergencyNumber,
            emergencyAddress, highSchool, highSchoolLocation, rowID = "";

    // Create local variables to link the buttons in the AdminActivity
    private Button backSortButton;
    private Button displayBidButton;

    // Creates a ListView variable to hold all of the data from users
    static ListView userList;

    // Creates ArrayList variables to hold the data of users and accounts
    static ArrayList<String> pnmsArray = new ArrayList<>();
    static ArrayList<String> bidArray = new ArrayList<>();

    // Creates a variable for the adapter for the ListView
    static ArrayAdapter<String> adapterUsers;

    // Variable to verify which sorting criteria was selected
    private String sortSelection;

    // Variable to get the string value of which house the admin logged in belongs to
    private String houseClaimed;

    // Variable to verify that the user
    private boolean flag1 = false;
    private boolean flag2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort);

        // Get the passed intents from the AdminActivity
        Intent intent = getIntent();
        houseClaimed = intent.getStringExtra("House");

        // Link the ListView to the local variable
        userList = (ListView) findViewById(R.id.usersList);

        // Set the adapter for the list of data
        adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, pnmsArray);

        // Sets the adapter
        userList.setAdapter(adapterUsers);

        // Reset the list view from previous data values
        pnmsArray.clear();
        //bidArray.clear();

        // Takes the user back to the AdminActivity
        backSortButton = (Button) findViewById(R.id.backSortBtn);
        backSortButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Start a new activity to sort through user data
                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                startActivity(intent);
            }
        });


        userList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                if(flag2 == true){
                    Toast.makeText(getApplicationContext(), "PNM granted a bid!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), "User added to bid list!", Toast.LENGTH_LONG).show();
                    bidArray.add(pnmsArray.get(position) + "\nHouse Claimed: " + houseClaimed);
                }
            }
        });

        // Spinner item for the sort selection
        final Spinner sort = (Spinner) findViewById(R.id.sortSelection);
        ArrayAdapter<CharSequence> sortAdapter = ArrayAdapter.createFromResource(this, R.array.sort_array, android.R.layout.simple_spinner_item);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sort.setAdapter(sortAdapter);

        // Verifying that an option was selected when the Spinner is clicked
        sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
                flag2 = false;

                // Getting the selected value in a local string and verifying it
                sortSelection = parent.getItemAtPosition(position).toString();

                if(flag1 == true){

                    // Notify the user that the sorting selection is invalid
                    Toast.makeText(getApplicationContext(), "Invalid sort criteria!", Toast.LENGTH_LONG).show();
                    // Clear the ListView of any existing data
                    pnmsArray.clear();

                    // Set the adapter for the list of data
                    adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, pnmsArray);

                    // Sets the adapter
                    userList.setAdapter(adapterUsers);
                    flag1 = false;
                }else{

                    // Clear the ListView of any existing data
                    pnmsArray.clear();

                    // Set the adapter for the list of data
                    adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, pnmsArray);

                    // Sets the adapter
                    userList.setAdapter(adapterUsers);

                    // Performs a query to get all rows in the DB
                    Cursor cursor = getContentResolver().query(InfoProvider.CONTENT_URI, UserData,null,null, null);

                    // Move the cursor to the first row
                    cursor.moveToNext();

                    // Verify that the cursor is valid and data exists in the Database
                    if(cursor != null && cursor.getCount() > 0){

                        // Iterate over each item in the database to find matching login credentials
                        for(int i = 0; i < cursor.getCount(); i++){

                            rowID = cursor.getString(0);
                            firstName = cursor.getString(1);
                            middleName = cursor.getString(2);
                            lastName = cursor.getString(3);
                            eMail = cursor.getString(4);
                            phoneNumber = cursor.getString(5);
                            address = cursor.getString(6);
                            city = cursor.getString(7);
                            state = cursor.getString(8);
                            zipCode = cursor.getString(9);
                            emergencyName = cursor.getString(10);
                            emergencyNumber = cursor.getString(11);
                            emergencyAddress = cursor.getString(12);
                            highSchool = cursor.getString(13);
                            highSchoolLocation = cursor.getString(14);
                            monthSelection = cursor.getString(15);
                            daySelection = cursor.getString(16);
                            yearSelection = cursor.getString(17);
                            relationSelection = cursor.getString(18);
                            highGPASelection = cursor.getString(19);
                            actSelection = cursor.getString(20);
                            satSelection = cursor.getString(21);
                            classSelection = cursor.getString(22);
                            collegeGPASelection = cursor.getString(23);
                            majorSelection = cursor.getString(24);
                            collegeSelection = cursor.getString(25);
                            firstPrefSelection = cursor.getString(26);
                            secondPrefSelection = cursor.getString(27);
                            thirdPrefSelection = cursor.getString(28);
                            activityOneSelection = cursor.getString(29);
                            activityTwoSelection = cursor.getString(30);
                            activityThreeSelection = cursor.getString(31);

                            // Allows the user to know which sort criteria was selected so that data can be displayed
                            switch(sortSelection){
                                case "Sort by...":

                                    // Clear the ListView of any existing data
                                    pnmsArray.clear();

                                    // Set the adapter for the list of data
                                    adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, pnmsArray);

                                    // Sets the adapter
                                    userList.setAdapter(adapterUsers);

                                    break;
                                case "Intended Major":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nMajor: " + majorSelection);
                                    break;

                                case "First Sorority Preference":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail +"\nSorority Preference 1: " + firstPrefSelection);
                                    break;

                                case "Second Sorority Preference":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nSorority Preference 2: " + secondPrefSelection);
                                    break;

                                case "Third Sorority Preference":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nSorority Preference 3: " + thirdPrefSelection);
                                    break;

                                case "First High School Involvement":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nHigh School Activity 1: " + activityOneSelection);
                                    break;

                                case "Second High School Involvement":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nHigh School Activity 2: " + activityTwoSelection);
                                    break;

                                case "Third High School Involvement":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nHigh School Activity 3: " + activityThreeSelection);
                                    break;

                                case "SAT Score":

                                    // Add each users info to the List View
                                    // TODO: Sort SAT scores from highest to lowest
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nSAT Score: " + satSelection);
                                    break;

                                case "ACT Score":

                                    // Add each users info to the List View
                                    // TODO: Sort ACT scores from highest to lowest
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nACT Score: " + actSelection);
                                    break;

                                case "High School GPA":

                                    // Add each users info to the List View
                                    // TODO: Sort high school GPA from highest to lowest
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nHigh School GPA: " + highGPASelection);
                                    break;

                                case "College GPA":

                                    // Add each users info to the List View
                                    // TODO: Sort college GPA from highest to lowest
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nCollege GPA: " + collegeGPASelection);
                                    break;

                                case "College Class":

                                    // Add each users info to the List View
                                    pnmsArray.add("PNM: " + firstName + " " + middleName + " " + lastName + "\nEmail: " + eMail + "\nClass: " + classSelection);
                                    break;

                                case "Display All":

                                    // Add each users info to the List View
                                    pnmsArray.add("First Name: "
                                    + firstName + ", Middle Name: "
                                    + middleName + ", Last Name: "
                                    + lastName + ", Email: "
                                    + eMail + ", Phone #: "
                                    + phoneNumber + ", Address: "
                                    + address + ", City: "
                                    + city + ", State: "
                                    + state + ", Zipcode: "
                                    + zipCode + ", Emergency Contact Name: "
                                    + emergencyName + ", Emergency Contact Phone #: "
                                    + emergencyNumber + ", Emergency Contact Address: "
                                    + emergencyAddress + ", High School: "
                                    + highSchool + ", High School Location: "
                                    + highSchoolLocation + ", Birthday: "
                                    + monthSelection + "/"
                                    + daySelection + "/"
                                    + yearSelection + ", Relation: "
                                    + relationSelection + ", High School GPA: "
                                    + highGPASelection + ", ACT Score: "
                                    + actSelection + ", SAT Score: "
                                    + satSelection + ", Class: "
                                    + classSelection + ", College GPA: "
                                    + collegeGPASelection + ", Major: "
                                    + majorSelection + ", College: "
                                    + collegeSelection + ", First Preference: "
                                    + firstPrefSelection + ", Second Preference: "
                                    + secondPrefSelection + ", Third Preference: "
                                    + thirdPrefSelection + ", High School Activity 1: "
                                    + activityOneSelection + ", High School Activity 2: "
                                    + activityTwoSelection + ", High School Activity 3: "
                                    + activityThreeSelection);
                                    break;

                                default:
                                    Toast.makeText(getApplicationContext(), "ERROR 202", Toast.LENGTH_LONG).show();
                                    break;
                            }

                            // Move the cursor to the next row
                            cursor.moveToNext();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), "Empty Database!", Toast.LENGTH_LONG).show();
                    }

                    // Set the adapter for the list of data
                    adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, pnmsArray);

                    // Sets the adapter
                    userList.setAdapter(adapterUsers);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Displays all of the users who have been selected for a bid
        displayBidButton = (Button) findViewById(R.id.displayBidBtn);
        displayBidButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                flag2 = true;

                // If the bidArray is empty notify the user
                if(!bidArray.isEmpty()){
                    // Notify the user that they are looking at the current list of bids
                    Toast.makeText(getApplicationContext(), "Displaying current bids", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), "No bids granted!", Toast.LENGTH_LONG).show();
                }

                //TODO: Save the list of all bids to a ContentProvider so it can be retrieved each time an admin logs in
                //TODO: Load the list of all bids and push them to the ArrayList

                // Setting the adapter to the correct ArrayList
                adapterUsers = new ArrayAdapter<String>(SortActivity.this, android.R.layout.simple_list_item_1, bidArray);
                userList.setAdapter(adapterUsers);

            }
        });
    }
}
