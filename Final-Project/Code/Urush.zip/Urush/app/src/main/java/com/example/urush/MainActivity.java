package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] Account = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_USERNAME,
            ToDoProvider.TODO_TABLE_COL_PASSWORD,
            ToDoProvider.TODO_TABLE_COL_ACTIVE,
            ToDoProvider.TODO_TABLE_COL_HOUSE,
            ToDoProvider.TODO_TABLE_COL_EMAIL
    };

    // Creates variables for the buttons in the MainActivity
    private Button loginButton;
    private Button registerButton;
    private Button newAccountButton;

    // Creates variables for the EditText fields in the MainActivity
    private EditText enteredUsername;
    private EditText enteredPassword;

    private String houseClaimed;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Sets the EditText fields in the MainActivity with the local variables
        // Show the cursor when the field is pressed
        enteredUsername = (EditText) findViewById(R.id.usernameValue);
        enteredUsername.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                enteredUsername.setCursorVisible(true);
            }
        });
        enteredUsername.setOnEditorActionListener(new TextView.OnEditorActionListener(){
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event){
                enteredUsername.setCursorVisible(true);
                return false;
            }
        });


        // Show the cursor when the field is pressed
        enteredPassword = (EditText) findViewById(R.id.passwordValue);
        enteredPassword.setCursorVisible(true);

        // Sets the login button and jumps to a new activity for the user when pressed
        loginButton = (Button) findViewById(R.id.loginBtn);
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Variable to detect an invalid login credential
                boolean invalid = false;

                // First check if the username and password are valid by scanning existing users in the DataBase
                ContentValues myCV = new ContentValues();

                // Perform a query to get all rows in the DB
                Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account,null,null,null);

                // Move the cursor to the first row
                cursor.moveToNext();

                // Verify that the cursor is valid and data exists in the Database
                if(cursor != null && cursor.getCount() > 0){

                    // Iterate over each item in the database to find matching login credentials
                    for(int i = 0; i < cursor.getCount(); i++){

                        // Getting the stored login values from the database and the EditText field
                        String usernameDB = cursor.getString(1);
                        String username = enteredUsername.getText().toString();
                        String passwordDB = cursor.getString(2);
                        String password = enteredPassword.getText().toString();
                        String activeDB = cursor.getString(3);
                        houseClaimed = cursor.getString(4);
                        String emailDB = cursor.getString(5);
                        String email = enteredUsername.getText().toString();

                        // If the provided credentials match with credentials in the data base and the account is active then login is successful and go to the new AdminActivity
                        if((usernameDB.equals(username) || emailDB.equals(email)) && passwordDB.equals(password) && activeDB.equals("TRUE")){

                            // This activity is where the user can login and search data in the DataBase and find the best matches
                            // Opens the new activity that contains the admin controls
                            Intent intent = new Intent(getApplicationContext(), AdminActivity.class);

                            // Passing the admins house to the next activity
                            intent.putExtra("House", houseClaimed);

                            // Launches the new activity
                            startActivity(intent);


                            // Notify the user that their login was successful
                            Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG).show();

                            // Move the increment value to the end of the database so it doesn't iterate anymore
                            i = cursor.getCount();

                            // Set the invalid variable to false
                            invalid = false;

                            // Reset the username and password EditText fields
                            enteredUsername.setText("");
                            enteredPassword.setText("");

                        // If the provided credentials match with credentials in the data base and the account is inactive then the login isn't approved
                        }else if((usernameDB.equals(username) || emailDB.equals(email)) && passwordDB.equals(password) && activeDB.equals("FALSE")){

                            // Notify the user that their account hasn't been approved yet
                            Toast.makeText(getApplicationContext(), "Unapproved Login!", Toast.LENGTH_LONG).show();

                            // Move the increment value to the end of the database so it doesn't iterate anymore
                            i = cursor.getCount();

                            // Set the invalid variable to false
                            invalid = false;

                        // Else, the login credentials do not exist so set the invalid variable to true
                        }else{
                            invalid = true;
                        }

                        // Move the cursor to the next row
                        cursor.moveToNext();
                    }
                // Only occurs if no values exist in the account credentials database
                }else{
                    Toast.makeText(getApplicationContext(), "Database is empty!", Toast.LENGTH_LONG).show();
                }

                // If invalid is true then notify the user that the login credentials are incorrect
                if(invalid == true){
                    Toast.makeText(getApplicationContext(), "Invalid username/password!", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Sets the register button and jumps to a new activity for the user when pressed
        registerButton = (Button) findViewById(R.id.registerBtn);
        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // This activity is where a new user can fill out and submit a form of data that will be saved in the DataBase
                // Opens the new activity that contains the registration form
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);

                // Launches the new activity
                startActivity(intent);
            }
        });

        // Sets the create account button and jumps to a new activity for the user when pressed
        newAccountButton = (Button) findViewById(R.id.createAccountBtn);
        newAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // This activity allows current sorority members to create an admin account to login with
                // Opens the new activity that contains the create account form
                Intent intent = new Intent(getApplicationContext(), AccountActivity.class);

                // Launches the new activity
                startActivity(intent);
            }
        });
    }
}
