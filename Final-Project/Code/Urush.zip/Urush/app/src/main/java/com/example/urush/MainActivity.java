package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity{

    // Creates variables for the buttons in the MainActivity
    private Button loginButton;
    private Button registerButton;
    private Button newAccountButton;

    // Creates variables for the EditText fields in the MainActivity
    private EditText enteredUsername;
    private EditText enteredPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Sets the EditText fields in the MainActivity with the local variables
        enteredUsername = (EditText) findViewById(R.id.usernameValue);
        enteredPassword = (EditText) findViewById(R.id.passwordValue);

        // Sets the login button and jumps to a new activity for the user when pressed
        loginButton = (Button) findViewById(R.id.loginBtn);
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // First check if the username and password are valid by scanning existing users in the DataBase

                // This activity is where the user can login and search data in the DataBase and find the best matches
                // Opens the new activity that contains the admin controls
                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);

                // Launches the new activity
                startActivity(intent);

                // Reset the username and password EditText fields
                enteredUsername.setText("");
                enteredPassword.setText("");
            }
        });

        // Sets the register button and jumps to a new activity for the user when pressed
        registerButton = (Button) findViewById(R.id.registerBtn);
        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // This activity is where a new user can fill out and submit a form of data that will be saved in the DataBase
                // Opens the new activity that contains the registration form
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);

                // Launches the new activity
                startActivity(intent);
            }
        });

        // Sets the create account button and jumps to a new activity for the user when pressed
        newAccountButton = (Button) findViewById(R.id.createAccountBtn);
        newAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // This activity allows current sorority members to create an admin account to login with
                // Opens the new activity that contains the create account form
                Intent intent = new Intent(getApplicationContext(), AccountActivity.class);

                // Launches the new activity
                startActivity(intent);
            }
        });
    }
}
