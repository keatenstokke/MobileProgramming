package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AccountActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] Account = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_USERNAME,
            ToDoProvider.TODO_TABLE_COL_PASSWORD,
            ToDoProvider.TODO_TABLE_COL_ACTIVE,
            ToDoProvider.TODO_TABLE_COL_HOUSE,
            ToDoProvider.TODO_TABLE_COL_EMAIL
    };

    // Creates variables for the buttons in the RegisterActivity
    private Button backAccountButton;
    private Button submitAccountButton;

    // Creates the variables for the EditText fields in the RegisterActivity
    private EditText newUsername;
    private EditText newPassword;
    private EditText newEmail;

    // Creates the variable for the TextView field in the RegisterActivity
    private TextView infoSix;

    // Determines if the data submit button was pressed or not
    private boolean submitted = false;
    private boolean accountExists = false;

    // Variables for getting the EditText fields
    private String userName;
    private String passWord;
    private String eMail;
    private String houseName;

    private boolean flag1 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        // Link the EditText/TextView fields with the local variables
        newUsername = (EditText) findViewById(R.id.newUsernameValue);
        newPassword = (EditText) findViewById(R.id.newPasswordValue);
        newEmail = (EditText) findViewById(R.id.newEmailValue);
        infoSix = (TextView) findViewById(R.id.infoSixView);

        // Spinner item for the sorority house selection
        final Spinner house = (Spinner) findViewById(R.id.houseSelection);
        ArrayAdapter<CharSequence> houseAdapter = ArrayAdapter.createFromResource(this, R.array.sorority_array, android.R.layout.simple_spinner_item);
        houseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        house.setAdapter(houseAdapter);

        // Verifying that an option was selected when the Spinner is clicked
        house.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                houseName = parent.getItemAtPosition(position).toString();
                if(houseName.equals("Sorority House")){
                    flag1 = true;
                }else{
                    flag1 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Sets the submit button for a user to create a new account to login with
        submitAccountButton = (Button) findViewById(R.id.submitAccountBtn);
        submitAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // If true, notifies the user of their submission and brings them to the MainActivity
                if(submitted == true){
                    Toast.makeText(getApplicationContext(), "Data submitted.", Toast.LENGTH_LONG).show();
                    // Returns the user to the MainActivity
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                // Else, notifies the user that a field is incorrect
                }else{
                    submitted = true;
                    // Check if the username/password/email field have values
                    if(newUsername.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid username.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(newPassword.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid password.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(newEmail.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid email.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(!newEmail.getText().toString().contains("@") || !newEmail.getText().toString().contains(".")){
                        Toast.makeText(getApplicationContext(), "Please enter a valid email.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }

                    // Notifies the user of a successful submission
                    if(submitted == true){

                        // Reset the Bool variable
                        accountExists = false;

                        // If a successful submission occurred, hide the keyboard
                        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                        // Get the account info from the EditText fields
                        userName = newUsername.getText().toString();
                        passWord = newPassword.getText().toString();
                        eMail = newEmail.getText().toString();

                        // Push account info data to the DB
                        ContentValues myCV = new ContentValues();

                        // Performs a query to get all rows in the DB
                        Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account, null, null, null);

                        // Move the cursor to the first row
                        cursor.moveToNext();

                        // Verify that the cursor is valid and data exists in the Database
                        if(cursor != null && cursor.getCount() > 0){

                            // Iterate over each item in the database to find matching login credentials
                            for(int i = 0; i < cursor.getCount(); i++){

                                // Getting the stored login values from the database and displaying them in the ListView
                                String usernameDB = cursor.getString(1);
                                String emailDB = cursor.getString(4);

                                // Check if the username or email already exists
                                if(userName.equals(usernameDB)){
                                    accountExists = true;
                                    submitted = false;
                                    Toast.makeText(getApplicationContext(), "Username already exists!", Toast.LENGTH_LONG).show();
                                }

                                if(eMail.equals(emailDB)){
                                    accountExists = true;
                                    submitted = false;
                                    Toast.makeText(getApplicationContext(), "Email already exists!", Toast.LENGTH_LONG).show();
                                }

                                // Move the cursor to the next row
                                cursor.moveToNext();
                            }

                        }

                        if(accountExists == false){
                            // Get the account information and add it to the DataBase
                            myCV.put(ToDoProvider.TODO_TABLE_COL_USERNAME, userName);
                            myCV.put(ToDoProvider.TODO_TABLE_COL_PASSWORD, passWord);
                            myCV.put(ToDoProvider.TODO_TABLE_COL_ACTIVE, "FALSE");
                            myCV.put(ToDoProvider.TODO_TABLE_COL_HOUSE, houseName);
                            myCV.put(ToDoProvider.TODO_TABLE_COL_EMAIL, eMail);

                            // Perform the insert function using the ContentProvider
                            getContentResolver().insert(ToDoProvider.CONTENT_URI, myCV);

                            // Notify the user that a successful account was created and is pending approval
                            infoSix.setText("Your request to create an account has been submitted and is pending approval. An authorized administrator will review your request. \nPress the back button.");

                        }
                    }
                }
            }
        });

        // Sets the back button when creating an account and jumps back to the MainActivity when pressed
        backAccountButton = (Button) findViewById(R.id.backAccountBtn);
        backAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Notifies the user of the status of their submission
                if(submitted == false){
                    Toast.makeText(getApplicationContext(), "Data was NOT saved!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Successful submission!", Toast.LENGTH_LONG).show();
                }

                // Opens the MainActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }
}