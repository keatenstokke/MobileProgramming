package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AccountActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] Account = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_USERNAME,
            ToDoProvider.TODO_TABLE_COL_PASSWORD,
            ToDoProvider.TODO_TABLE_COL_ACTIVE,
            ToDoProvider.TODO_TABLE_COL_EMAIL
    };

    // Creates variables for the buttons in the RegisterActivity
    private Button backAccountButton;
    private Button submitAccountButton;

    // Creates the variables for the EditText fields in the RegisterActivity
    private EditText newUsername;
    private EditText newPassword;
    private EditText newEmail;

    // Creates the variable for the TextView field in the RegisterActivity
    private TextView infoSix;

    // Determines if the data submit button was pressed or not
    private boolean submitted = false;

    // Variables for getting the EditText fields
    private String userName;
    private String passWord;
    private String eMail;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        // Link the EditText/TextView fields with the local variables
        newUsername = (EditText) findViewById(R.id.newUsernameValue);
        newPassword = (EditText) findViewById(R.id.newPasswordValue);
        newEmail = (EditText) findViewById(R.id.newEmailValue);
        infoSix = (TextView) findViewById(R.id.infoSixView);

        // Sets the submit button for a user to create a new account to login with
        submitAccountButton = (Button) findViewById(R.id.submitAccountBtn);
        submitAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // If true, notifies the user of their submission and brings them to the MainActivity
                if(submitted == true){
                    Toast.makeText(getApplicationContext(), "Data submitted.", Toast.LENGTH_LONG).show();
                    // Returns the user to the MainActivity
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                // Else, notifies the user that a field is incorrect
                }else{
                    submitted = true;
                    // Check if the username/password/email field have values
                    if(newUsername.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid username.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(newPassword.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid password.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(newEmail.getText().toString().length() <= 0){
                        Toast.makeText(getApplicationContext(), "Please enter a valid email.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }else if(!newEmail.getText().toString().contains("@") || !newEmail.getText().toString().contains(".")){
                        Toast.makeText(getApplicationContext(), "Please enter a valid email.", Toast.LENGTH_LONG).show();
                        submitted = false;
                    }

                    // Notifies the user of a successful submission
                    if(submitted == true){
                        // If a successful submission occurred, hide the keyboard
                        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                        // Get the account info from the EditText fields
                        userName = newUsername.getText().toString();
                        passWord = newPassword.getText().toString();
                        eMail = newEmail.getText().toString();

                        // Push account info data to the DB
                        ContentValues myCV = new ContentValues();

                        // Get the account information and add it to the DataBase
                        myCV.put(ToDoProvider.TODO_TABLE_COL_USERNAME, userName);
                        myCV.put(ToDoProvider.TODO_TABLE_COL_PASSWORD, passWord);
                        myCV.put(ToDoProvider.TODO_TABLE_COL_ACTIVE, "FALSE");
                        myCV.put(ToDoProvider.TODO_TABLE_COL_EMAIL, eMail);

                        // Perform the insert function using the ContentProvider
                        getContentResolver().insert(ToDoProvider.CONTENT_URI, myCV);

                        // Notify the user that a successful account was created and is pending approval
                        infoSix.setText("Your request to create an account has been submitted and is pending approval. An authorized administrator will review your request. \nPress the back button.");
                    }
                }
            }
        });

        // Sets the back button when creating an account and jumps back to the MainActivity when pressed
        backAccountButton = (Button) findViewById(R.id.backAccountBtn);
        backAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Notifies the user of the status of their submission
                if(submitted == false){
                    Toast.makeText(getApplicationContext(), "Data was NOT saved!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Successful submission!", Toast.LENGTH_LONG).show();
                }

                // Opens the MainActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}