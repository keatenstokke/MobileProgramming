package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class AdminActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] UserData = new String[]{
            InfoProvider.TODO_TABLE_COL_ID, InfoProvider.TODO_TABLE_COL_FIRST_NAME, InfoProvider.TODO_TABLE_COL_MIDDLE_NAME,
            InfoProvider.TODO_TABLE_COL_LAST_NAME, InfoProvider.TODO_TABLE_COL_EMAIL, InfoProvider.TODO_TABLE_COL_PHONE_NUMBER,
            InfoProvider.TODO_TABLE_COL_ADDRESS, InfoProvider.TODO_TABLE_COL_CITY, InfoProvider.TODO_TABLE_COL_STATE,
            InfoProvider.TODO_TABLE_COL_ZIPCODE, InfoProvider.TODO_TABLE_COL_EMERGENCY_NAME,
            InfoProvider.TODO_TABLE_COL_EMERGENCY_NUMBER, InfoProvider.TODO_TABLE_COL_EMERGENCY_ADDRESS,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL, InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_LOCATION,
            InfoProvider.TODO_TABLE_COL_BIRTH_MONTH, InfoProvider.TODO_TABLE_COL_BIRTH_DAY,
            InfoProvider.TODO_TABLE_COL_BIRTH_YEAR, InfoProvider.TODO_TABLE_COL_EMERGENCY_RELATION,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_GPA, InfoProvider.TODO_TABLE_COL_ACT_SCORE,
            InfoProvider.TODO_TABLE_COL_SAT_SCORE, InfoProvider.TODO_TABLE_COL_CLASS, InfoProvider.TODO_TABLE_COL_COLLEGE_GPA,
            InfoProvider.TODO_TABLE_COL_MAJOR, InfoProvider.TODO_TABLE_COL_COLLEGE, InfoProvider.TODO_TABLE_COL_SORORITY_ONE,
            InfoProvider.TODO_TABLE_COL_SORORITY_TWO, InfoProvider.TODO_TABLE_COL_SORORITY_THREE,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_ONE, InfoProvider.TODO_TABLE_COL_ACTIVITY_TWO,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_THREE
    };

    // Create local variables to link the buttons in the AdminActivity
    private Button approveButton;
    private Button backAdminButton;
    private Button sortButton;

    // Creates a ListView variable to hold all of the data from users
    static ListView dataList;

    // Creates ArrayList variables to hold the data of users and accounts
    static ArrayList<String> pnmsArray = new ArrayList<>();
    static ArrayList<String> accountsArray = new ArrayList<>();

    // Creates a variable for the adapter for the ListView
    static ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Notify the user that their login was successful
        Toast.makeText(getApplicationContext(), "Login Successful!", Toast.LENGTH_LONG).show();



        // If the back button is pressed, send the user to the MainActivity
        backAdminButton = findViewById(R.id.backAdminBtn);
        backAdminButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Notify the user that they have logged out
                Toast.makeText(getApplicationContext(), "Logout Successful!", Toast.LENGTH_LONG).show();

                // Returns the user back to the MainActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        //TODO: Approve button - display unapproved accounts and allow them to change them to active status
        approveButton = findViewById(R.id.approveBtn);
        approveButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

            }
        });

        //TODO: Sort button - display all users registration info and allow them to sort through it
        sortButton = findViewById(R.id.sortBtn);
        sortButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

            }
        });

    }
}
