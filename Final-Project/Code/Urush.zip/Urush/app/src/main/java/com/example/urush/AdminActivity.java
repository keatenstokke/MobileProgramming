package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

public class AdminActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] Account = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_USERNAME,
            ToDoProvider.TODO_TABLE_COL_PASSWORD,
            ToDoProvider.TODO_TABLE_COL_ACTIVE,
            ToDoProvider.TODO_TABLE_COL_HOUSE,
            ToDoProvider.TODO_TABLE_COL_EMAIL
    };

    // Create local variables to link the buttons in the AdminActivity
    private Button approveButton;
    private Button backAdminButton;
    private Button sortButton;
    private Button deleteButton;

    // Creates a ListView variable to hold all of the data from users
    static ListView dataList;

    // Creates ArrayList variables to hold the data of users and accounts
    static ArrayList<String> accountsArray = new ArrayList<>();

    // Creates a variable for the adapter for the ListView
    static ArrayAdapter<String> adapterAccounts;

    // Creates boolean variable to notify the user if there are accounts that exist to be authorized or not
    private Boolean noApproval = FALSE;

    private String houseClaimed;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Link the ListView to the local variable
        dataList = (ListView) findViewById(R.id.dataList);

        // Set the adapter for the list of data
        adapterAccounts = new ArrayAdapter<String>(AdminActivity.this, android.R.layout.simple_list_item_1, accountsArray);

        // Sets the adapter
        dataList.setAdapter(adapterAccounts);

        // Clear any current elements in the ListView
        accountsArray.clear();

        // Get the passed intents from the MainActivity
        Intent intent = getIntent();
        houseClaimed = intent.getStringExtra("House");

        // If the back button is pressed, send the user to the MainActivity
        backAdminButton = (Button) findViewById(R.id.backAdminBtn);
        backAdminButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Notify the user that they have logged out
                Toast.makeText(getApplicationContext(), "Logout successful!", Toast.LENGTH_LONG).show();

                // Returns the user back to the MainActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        //TODO: Approve button - display unapproved accounts and allow them to change them to active status
        approveButton = findViewById(R.id.approveBtn);
        approveButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Variable to notify the user how many accounts there are to authorize
                int count = 0;

                // Reset the bool variable that lets the user know if there are no accounts to approve
                noApproval = FALSE;

                // Clear any current elements in the ListView
                accountsArray.clear();

                // Performs a query to get all rows in the DB
                Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account,null,null, null);

                // Move the cursor to the first row
                cursor.moveToNext();

                // Verify that the cursor is valid and data exists in the Database
                if(cursor != null && cursor.getCount() > 0){

                    // Iterate over each item in the database to find matching login credentials
                    for(int i = 0; i < cursor.getCount(); i++){

                        // Getting the stored login values from the database and displaying them in the ListView
                        String usernameDB = cursor.getString(1);
                        String activeDB = cursor.getString(3);
                        String houseDB = cursor.getString(4);
                        String emailDB = cursor.getString(5);

                        // If an account has a value of FALSE, add it to the ListView for approval
                        if(activeDB.equals("FALSE")){
                            accountsArray.add("User: " + usernameDB + ", " + activeDB + ", " + houseDB + ", " + emailDB);
                            noApproval = TRUE;
                            count++;
                        }

                        // Move the cursor to the next row
                        cursor.moveToNext();
                    }
                }
                if(noApproval == FALSE){
                    Toast.makeText(getApplicationContext(), "No accounts to authorize!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), count + " account(s) to authorize!", Toast.LENGTH_LONG).show();
                }
                // Set the adapter for the list of data
                adapterAccounts = new ArrayAdapter<String>(AdminActivity.this, android.R.layout.simple_list_item_1, accountsArray);

                // Sets the adapter
                dataList.setAdapter(adapterAccounts);

                // Enables a click listener so that the user can approve an account when it is selected in the ListView
                dataList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                        // Performs a query to get all rows in the DB
                        Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account,null,null, null);

                        // Move the cursor to the first row
                        cursor.moveToNext();

                        // Verify that the cursor is valid and data exists in the Database
                        if(cursor != null && cursor.getCount() > 0){

                            // Iterate over each item in the database to find matching login credentials
                            for(int i = 0; i < cursor.getCount(); i++){

                                // Getting the stored login values from the database and displaying them in the ListView
                                String rowID = cursor.getString(0);
                                String usernameDB = cursor.getString(1);
                                String passwordDB = cursor.getString(2);
                                String activeDB = cursor.getString(3);
                                String houseDB = cursor.getString(4);
                                String emailDB = cursor.getString(5);

                                // If the selected user matches to row in the database, update the users "active" status
                                if(accountsArray.get(position).toString().equals("User: " + usernameDB + ", " + activeDB + ", " + houseDB + ", " + emailDB)){

                                    // Push updated user info data to the DB
                                    ContentValues myCV = new ContentValues();
                                    myCV.put(ToDoProvider.TODO_TABLE_COL_USERNAME, usernameDB);
                                    myCV.put(ToDoProvider.TODO_TABLE_COL_PASSWORD, passwordDB);
                                    myCV.put(ToDoProvider.TODO_TABLE_COL_ACTIVE, "TRUE");
                                    myCV.put(ToDoProvider.TODO_TABLE_COL_EMAIL, emailDB);
                                    getContentResolver().update(Uri.parse(ToDoProvider.CONTENT_URI + "/" + rowID), myCV, null, null);
                                }
                                // Move the cursor to the next row
                                cursor.moveToNext();
                            }
                        }

                        // Set the adapter for the list of data
                        adapterAccounts = new ArrayAdapter<String>(AdminActivity.this, android.R.layout.simple_list_item_1, accountsArray);

                        // Sets the adapter
                        dataList.setAdapter(adapterAccounts);

                        // Notify the user that the account selected was authorized
                        Toast.makeText(getApplicationContext(), "User authorized!", Toast.LENGTH_LONG).show();
                    }
                });

            }
        });


        // If the delete account button is pressed, remove accounts from the Admin list
        deleteButton = (Button) findViewById(R.id.deleteBtn);
        deleteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Variable to notify the user how many accounts there are to delete
                int count = 0;

                // Clear any current elements in the ListView
                accountsArray.clear();

                // Performs a query to get all rows in the DB
                Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account,null,null, null);

                // Move the cursor to the first row
                cursor.moveToNext();

                // Verify that the cursor is valid and data exists in the Database
                if(cursor != null && cursor.getCount() > 0){

                    // Iterate over each item in the database to find matching login credentials
                    for(int i = 0; i < cursor.getCount(); i++){

                        // Getting the stored login values from the database and displaying them in the ListView
                        String rowID = cursor.getString(0);
                        String usernameDB = cursor.getString(1);
                        String passwordDB = cursor.getString(2);
                        String activeDB = cursor.getString(3);
                        String houseDB = cursor.getString(4);
                        String emailDB = cursor.getString(5);


                        // Add all users to the List View
                        accountsArray.add("User: " + usernameDB + ", " + activeDB + ", " + emailDB);

                        // Increment the accounts variable
                        count++;

                        // Move the cursor to the next row
                        cursor.moveToNext();
                    }
                }

                if(count == 0){
                    Toast.makeText(getApplicationContext(), "No users to delete!", Toast.LENGTH_LONG).show();
                }

                // Set the adapter for the list of data
                adapterAccounts = new ArrayAdapter<String>(AdminActivity.this, android.R.layout.simple_list_item_1, accountsArray);

                // Sets the adapter
                dataList.setAdapter(adapterAccounts);

                // When an item in the list is selected, delete it
                dataList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                        // Performs a query to get all rows in the DB
                        Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, Account, null, null, null);

                        // Move the cursor to the first row
                        cursor.moveToNext();

                        Toast.makeText(getApplicationContext(), "delete!", Toast.LENGTH_LONG).show();
                        // Verify that the cursor is valid and data exists in the Database
                        if(cursor != null && cursor.getCount() > 0){

                            // Iterate over each item in the database to find matching login credentials
                            for(int i = 0; i < cursor.getCount(); i++){

                                // Getting the stored login values from the database and displaying them in the ListView
                                String rowID = cursor.getString(0);
                                String usernameDB = cursor.getString(1);
                                String activeDB = cursor.getString(3);
                                String houseDB = cursor.getString(4);
                                String emailDB = cursor.getString(5);

                                // If the selected user matches to row in the database, update the users "active" status
                                if(accountsArray.get(position).toString().equals("User: " + usernameDB + ", " + activeDB + ", " + emailDB)){

                                    // Delete the row from the ContentProvider and the ArrayList
                                    getContentResolver().delete(Uri.parse(ToDoProvider.CONTENT_URI + "/" + rowID), null, null);
                                    Toast.makeText(getApplicationContext(), "User deleted!", Toast.LENGTH_LONG).show();
                                }
                                // Move the cursor to the next row
                                cursor.moveToNext();

                            }
                        }else{
                            Toast.makeText(getApplicationContext(), "No users to delete!", Toast.LENGTH_LONG).show();
                        }

                    }
                });

            }
        });

        //TODO: Sort button - display all users registration info and allow them to sort through it
        sortButton = findViewById(R.id.sortBtn);
        sortButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Clear any current elements in the ListView
                accountsArray.clear();

                // Start a new activity to sort through user data
                Intent intent = new Intent(getApplicationContext(), SortActivity.class);

                // Passing the admins house to the next activity
                intent.putExtra("House", houseClaimed);

                startActivity(intent);


            }
        });

    }
}
