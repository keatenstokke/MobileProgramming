package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity{

    // Creates the variable for the submit button on the RegisterActivity
    private Button submitRegistrationButton;

    // Variable to know if the submit button was pressed
    private boolean submitted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Toast.makeText(getApplicationContext(), "Complete the form.", Toast.LENGTH_LONG).show();

        // Map the button from the RegisterActivity to the local variable and set up a click listener
        submitRegistrationButton = (Button) findViewById(R.id.submitRegistrationBtn);
        submitRegistrationButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //TODO: Check if all fields are filled out and not empty

                //TODO: Push all valid form data to the content provider
                submitted = true;
                if(submitted == true){
                    Toast.makeText(getApplicationContext(), "Rush registration submitted!", Toast.LENGTH_LONG).show();

                    // Returns the user back to the MainActivity
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });

    }

}
