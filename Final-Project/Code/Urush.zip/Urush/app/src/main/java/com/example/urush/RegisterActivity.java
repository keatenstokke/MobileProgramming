package com.example.urush;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity{

    // Set the projection for the columns to be returned for the DB
    static String [] UserData = new String[]{
            InfoProvider.TODO_TABLE_COL_ID, InfoProvider.TODO_TABLE_COL_FIRST_NAME, InfoProvider.TODO_TABLE_COL_MIDDLE_NAME,
            InfoProvider.TODO_TABLE_COL_LAST_NAME, InfoProvider.TODO_TABLE_COL_EMAIL, InfoProvider.TODO_TABLE_COL_PHONE_NUMBER,
            InfoProvider.TODO_TABLE_COL_ADDRESS, InfoProvider.TODO_TABLE_COL_CITY, InfoProvider.TODO_TABLE_COL_STATE,
            InfoProvider.TODO_TABLE_COL_ZIPCODE, InfoProvider.TODO_TABLE_COL_EMERGENCY_NAME,
            InfoProvider.TODO_TABLE_COL_EMERGENCY_NUMBER, InfoProvider.TODO_TABLE_COL_EMERGENCY_ADDRESS,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL, InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_LOCATION,
            InfoProvider.TODO_TABLE_COL_BIRTH_MONTH, InfoProvider.TODO_TABLE_COL_BIRTH_DAY,
            InfoProvider.TODO_TABLE_COL_BIRTH_YEAR, InfoProvider.TODO_TABLE_COL_EMERGENCY_RELATION,
            InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_GPA, InfoProvider.TODO_TABLE_COL_ACT_SCORE,
            InfoProvider.TODO_TABLE_COL_SAT_SCORE, InfoProvider.TODO_TABLE_COL_CLASS, InfoProvider.TODO_TABLE_COL_COLLEGE_GPA,
            InfoProvider.TODO_TABLE_COL_MAJOR, InfoProvider.TODO_TABLE_COL_COLLEGE, InfoProvider.TODO_TABLE_COL_SORORITY_ONE,
            InfoProvider.TODO_TABLE_COL_SORORITY_TWO, InfoProvider.TODO_TABLE_COL_SORORITY_THREE,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_ONE, InfoProvider.TODO_TABLE_COL_ACTIVITY_TWO,
            InfoProvider.TODO_TABLE_COL_ACTIVITY_THREE
    };

    // Create a local variable for the TextView to display a message after submission
    private TextView submitRegistration;

    // Creates the variable for the buttons on the RegisterActivity
    private Button submitRegistrationButton, backRegistrationButton;

    // Creates local variables to link the EditText fields to local variables
    private EditText firstNameField, middleNameField, lastNameField, emailField, phoneField, addressField, cityField,
            stateField, zipcodeField, emNameField, emNumberField, emAddressField, hsField, hsLocationField;

    // Creates local String variables for all the selected spinner values
    private String monthSelection, daySelection, yearSelection, relationSelection, highGPASelection, actSelection,
            satSelection, classSelection, collegeGPASelection, majorSelection, collegeSelection, firstPrefSelection,
            secondPrefSelection, thirdPrefSelection, activityOneSelection, activityTwoSelection, activityThreeSelection,
            firstName, middleName, lastName, eMail, phoneNumber, address, city, state, zipCode, emergencyName, emergencyNumber,
            emergencyAddress, highSchool, highSchoolLocation = "";

    // Variable to know if the submit button was pressed
    private boolean submitted, submitted1 = false;
    private boolean flag1, flag2, flag3, flag4, flag5, flag6, flag7, flag8, flag9, flag10, flag11,
            flag12, flag13, flag14, flag15, flag16, flag17, flag18, flag19, flag20, flag21, flag22,
            flag23, flag24, flag25, flag26, flag27, flag28, flag29, flag30, flag31 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Notify the user to complete the form
        Toast.makeText(getApplicationContext(), "Complete the form.", Toast.LENGTH_LONG).show();

        // Link the TextView and EditText fields with local variables
        submitRegistration = (TextView) findViewById(R.id.infoSevenView);
        firstNameField = (EditText) findViewById(R.id.firstNameValue);
        middleNameField = (EditText) findViewById(R.id.middleNameValue);
        lastNameField = (EditText) findViewById(R.id.lastNameValue);
        emailField = (EditText) findViewById(R.id.emailValue);
        phoneField = (EditText) findViewById(R.id.phoneValue);
        addressField = (EditText) findViewById(R.id.addressValue);
        cityField = (EditText) findViewById(R.id.cityValue);
        stateField = (EditText) findViewById(R.id.stateValue);
        zipcodeField = (EditText) findViewById(R.id.zipValue);
        emNameField = (EditText) findViewById(R.id.emNameValue);
        emNumberField = (EditText) findViewById(R.id.emNumberValue);
        emAddressField = (EditText) findViewById(R.id.emAddressValue);
        hsField = (EditText) findViewById(R.id.highSchoolValue);
        hsLocationField = (EditText) findViewById(R.id.hsLocationValue);

        // Spinner item for the month selection
        final Spinner month = (Spinner) findViewById(R.id.monthValue);
        ArrayAdapter<CharSequence> monthAdapter = ArrayAdapter.createFromResource(this, R.array.month_array, android.R.layout.simple_spinner_item);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month.setAdapter(monthAdapter);

        // Spinner item for the day selection
        final Spinner day = (Spinner) findViewById(R.id.dayValue);
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(this, R.array.day_array, android.R.layout.simple_spinner_item);
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        day.setAdapter(dayAdapter);

        // Spinner item for the year selection
        final Spinner year = (Spinner) findViewById(R.id.yearValue);
        ArrayAdapter<CharSequence> yearAdapter = ArrayAdapter.createFromResource(this, R.array.year_array, android.R.layout.simple_spinner_item);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year.setAdapter(yearAdapter);

        // Spinner item for the emergency selection
        final Spinner emergency = (Spinner) findViewById(R.id.emRelateValue);
        ArrayAdapter<CharSequence> emergencyAdapter = ArrayAdapter.createFromResource(this, R.array.emergency_array, android.R.layout.simple_spinner_item);
        emergencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        emergency.setAdapter(emergencyAdapter);

        // Spinner item for the high school gpa selection
        final Spinner gpaHigh = (Spinner) findViewById(R.id.gpaValue);
        ArrayAdapter<CharSequence> gpaAdapter = ArrayAdapter.createFromResource(this, R.array.gpa_array, android.R.layout.simple_spinner_item);
        gpaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gpaHigh.setAdapter(gpaAdapter);

        // Spinner item for the ACT selection
        final Spinner act = (Spinner) findViewById(R.id.actValue);
        ArrayAdapter<CharSequence> actAdapter = ArrayAdapter.createFromResource(this, R.array.act_array, android.R.layout.simple_spinner_item);
        actAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        act.setAdapter(actAdapter);

        // Spinner item for the SAT selection
        final Spinner sat = (Spinner) findViewById(R.id.satValue);
        ArrayAdapter<CharSequence> satAdapter = ArrayAdapter.createFromResource(this, R.array.sat_array, android.R.layout.simple_spinner_item);
        satAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sat.setAdapter(satAdapter);

        // Spinner item for the college class selection
        final Spinner schoolClass = (Spinner) findViewById(R.id.classValue);
        ArrayAdapter<CharSequence> schoolClassAdapter = ArrayAdapter.createFromResource(this, R.array.class_array, android.R.layout.simple_spinner_item);
        schoolClassAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        schoolClass.setAdapter(schoolClassAdapter);

        // Spinner item for the college gpa selection
        final Spinner gpaCollege = (Spinner) findViewById(R.id.cgpaValue);
        ArrayAdapter<CharSequence> gpaCollegeAdapter = ArrayAdapter.createFromResource(this, R.array.cgpa_array, android.R.layout.simple_spinner_item);
        gpaCollegeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gpaCollege.setAdapter(gpaCollegeAdapter);

        // Spinner item for the college major selection
        final Spinner major = (Spinner) findViewById(R.id.majorValue);
        ArrayAdapter<CharSequence> majorAdapter = ArrayAdapter.createFromResource(this, R.array.major_array, android.R.layout.simple_spinner_item);
        majorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        major.setAdapter(majorAdapter);

        // Spinner item for the college selection
        final Spinner school = (Spinner) findViewById(R.id.schoolValue);
        ArrayAdapter<CharSequence> schoolAdapter = ArrayAdapter.createFromResource(this, R.array.school_array, android.R.layout.simple_spinner_item);
        schoolAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        school.setAdapter(schoolAdapter);

        // Spinner item for the sorority preference one selection
        final Spinner sororityOne = (Spinner) findViewById(R.id.houseOneValue);
        ArrayAdapter<CharSequence> sororityOneAdapter = ArrayAdapter.createFromResource(this, R.array.sorority_one_array, android.R.layout.simple_spinner_item);
        sororityOneAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sororityOne.setAdapter(sororityOneAdapter);

        // Spinner item for the sorority preference two selection
        final Spinner sororityTwo = (Spinner) findViewById(R.id.houseTwoValue);
        ArrayAdapter<CharSequence> sororityTwoAdapter = ArrayAdapter.createFromResource(this, R.array.sorority_two_array, android.R.layout.simple_spinner_item);
        sororityTwoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sororityTwo.setAdapter(sororityTwoAdapter);

        // Spinner item for the sorority preference three selection
        final Spinner sororityThree = (Spinner) findViewById(R.id.houseThreeValue);
        ArrayAdapter<CharSequence> sororityThreeAdapter = ArrayAdapter.createFromResource(this, R.array.sorority_three_array, android.R.layout.simple_spinner_item);
        sororityThreeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sororityThree.setAdapter(sororityThreeAdapter);

        // Spinner item for the high school activity one selection
        final Spinner activityOne = (Spinner) findViewById(R.id.activityOneValue);
        ArrayAdapter<CharSequence> activityOneAdapter = ArrayAdapter.createFromResource(this, R.array.activity_one_array, android.R.layout.simple_spinner_item);
        activityOneAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityOne.setAdapter(activityOneAdapter);

        // Spinner item for the high school activity two selection
        final Spinner activityTwo = (Spinner) findViewById(R.id.activityTwoValue);
        ArrayAdapter<CharSequence> activityTwoAdapter = ArrayAdapter.createFromResource(this, R.array.activity_two_array, android.R.layout.simple_spinner_item);
        activityTwoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityTwo.setAdapter(activityTwoAdapter);

        // Spinner item for the high school activity three selection
        final Spinner activityThree = (Spinner) findViewById(R.id.activityThreeValue);
        ArrayAdapter<CharSequence> activityThreeAdapter = ArrayAdapter.createFromResource(this, R.array.activity_three_array, android.R.layout.simple_spinner_item);
        activityThreeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityThree.setAdapter(activityThreeAdapter);

        // Verifying that an option was selected when the Spinner is clicked
        month.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                monthSelection = parent.getItemAtPosition(position).toString();
                if(monthSelection.equals("Birth Month")){
                    flag1 = true;
                }else{
                    flag1 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        day.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                daySelection = parent.getItemAtPosition(position).toString();
                if(daySelection.equals("Birth Day")){
                    flag2 = true;
                }else{
                    flag2 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        year.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                yearSelection = parent.getItemAtPosition(position).toString();
                if(yearSelection.equals("Birth Year")){
                    flag3 = true;
                }else{
                    flag3 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        emergency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                relationSelection = parent.getItemAtPosition(position).toString();
                if(relationSelection.equals("Emergency Contact Relation")){
                    flag4 = true;
                }else{
                    flag4 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        gpaHigh.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                highGPASelection = parent.getItemAtPosition(position).toString();
                if(highGPASelection.equals("High School GPA")){
                    flag5 = true;
                }else{
                    flag5 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        act.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                actSelection = parent.getItemAtPosition(position).toString();
                if(actSelection.equals("ACT Score")){
                    flag6 = true;
                }else{
                    flag6 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        sat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                satSelection = parent.getItemAtPosition(position).toString();
                if(satSelection.equals("SAT Score")){
                    flag7 = true;
                }else{
                    flag7 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        schoolClass.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                classSelection = parent.getItemAtPosition(position).toString();
                if(classSelection.equals("College Class")){
                    flag8 =  true;
                }else{
                    flag8 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        gpaCollege.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                collegeGPASelection = parent.getItemAtPosition(position).toString();
                if(collegeGPASelection.equals("College GPA")){
                    flag9 =  true;
                }else{
                    flag9 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        major.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                majorSelection = parent.getItemAtPosition(position).toString();
                if(majorSelection.equals("Intended Major")){
                    flag10 =  true;
                }else{
                    flag10 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        school.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                collegeSelection = parent.getItemAtPosition(position).toString();
                if(collegeSelection.equals("College Attending")){
                    flag11 =  true;
                }else{
                    flag11 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        sororityOne.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                firstPrefSelection = parent.getItemAtPosition(position).toString();
                if(firstPrefSelection.equals("First Sorority Preference")){
                    flag12 =  true;
                }else{
                    flag12 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        sororityTwo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                secondPrefSelection = parent.getItemAtPosition(position).toString();
                if(secondPrefSelection.equals("Second Sorority Preference")){
                    flag13 =  true;
                }else{
                    flag13 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        sororityThree.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                thirdPrefSelection = parent.getItemAtPosition(position).toString();
                if(thirdPrefSelection.equals("Third Sorority Preference")){
                    flag14 =  true;
                }else{
                    flag14 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        activityOne.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                activityOneSelection = parent.getItemAtPosition(position).toString();
                if(activityOneSelection.equals("High School Involvement")){
                    flag15 =  true;
                }else{
                    flag15 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        activityTwo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                activityTwoSelection = parent.getItemAtPosition(position).toString();
                if(activityTwoSelection.equals("High School Involvement")){
                    flag16 =  true;
                }else{
                    flag16 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Verifying that an option was selected when the Spinner is clicked
        activityThree.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

                // Getting the selected value in a local string and verifying it
                activityThreeSelection = parent.getItemAtPosition(position).toString();
                if(activityThreeSelection.equals("High School Involvement")){
                    flag17 =  true;
                }else{
                    flag17 = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){
            }
        });

        // Handles the "back" button if it is pressed
        backRegistrationButton = (Button) findViewById(R.id.backRegisterBtn);
        backRegistrationButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Notifies the user on the status of their submission
                if(submitted == false){
                    Toast.makeText(getApplicationContext(), "Data NOT saved!", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Rush registration submitted!", Toast.LENGTH_LONG).show();
                }

                // Returns the user back to the MainActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });


        // Map the button from the RegisterActivity to the local variable and set up a click listener
        submitRegistrationButton = (Button) findViewById(R.id.submitRegistrationBtn);
        submitRegistrationButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                // Set the local String variables to the EditText field values and check if its valid
                firstName = firstNameField.getText().toString();
                if(firstName.length() == 0){
                    flag18 = true;
                }else{
                    flag18 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                middleName = middleNameField.getText().toString();
                if(middleName.length() == 0){
                    flag19 = true;
                }else{
                    flag19 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                lastName = lastNameField.getText().toString();
                if(lastName.length() == 0){
                    flag20 = true;
                }else{
                    flag20 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                eMail = emailField.getText().toString();
                if(eMail.length() == 0 || !eMail.contains("@") || !eMail.contains(".")){
                    flag21 = true;
                }else{
                    flag21 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                phoneNumber = phoneField.getText().toString();
                if(phoneNumber.length() == 0){
                    flag22 = true;
                }else{
                    flag22 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                address = addressField.getText().toString();
                if(address.length() == 0){
                    flag23 = true;
                }else{
                    flag23 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                city = cityField.getText().toString();
                if(city.length() == 0){
                    flag24 = true;
                }else{
                    flag24 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                state = stateField.getText().toString();
                if(state.length() == 0){
                    flag25 = true;
                }else{
                    flag25 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                zipCode = zipcodeField.getText().toString();
                if(zipCode.length() == 0){
                    flag26 = true;
                }else{
                    flag26 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                emergencyName = emNameField.getText().toString();
                if(emergencyName.length() == 0){
                    flag27 = true;
                }else{
                    flag27 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                emergencyNumber = emNumberField.getText().toString();
                if(emergencyNumber.length() == 0){
                    flag28 = true;
                }else{
                    flag28 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                emergencyAddress = emAddressField.getText().toString();
                if(emergencyAddress.length() == 0){
                    flag29 = true;
                }else{
                    flag29 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                highSchool = hsField.getText().toString();
                if(highSchool.length() == 0){
                    flag30 = true;
                }else{
                    flag30 = false;
                }

                // Set the local String variables to the EditText field values and check if its valid
                highSchoolLocation = hsLocationField.getText().toString();
                if(highSchoolLocation.length() == 0){
                    flag31 = true;
                }else{
                    flag31 = false;
                }

                // A flag was triggered which means one or more of the fields in the form is incomplete or invalid
                if(flag1 == true || flag2 == true || flag3 == true || flag4 == true || flag5 == true || flag6 == true || flag7 == true ||
                        flag8 == true || flag9 == true || flag10 == true || flag11 == true || flag12 == true || flag13 == true || flag14 == true ||
                        flag15 == true || flag16 == true || flag17 == true || flag18 == true || flag19 == true || flag20 == true || flag21 == true ||
                        flag22 == true || flag23 == true || flag24 == true || flag25 == true || flag26 == true || flag27 == true || flag28 == true ||
                        flag29 == true || flag30 == true || flag31 == true){
                    Toast.makeText(getApplicationContext(), "One or more invalid fields!", Toast.LENGTH_LONG).show();
                    submitRegistration.setText("");
                }else{
                    submitted = true;
                }
                if(submitted1 == true){
                    // Returns the user back to the MainActivity
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
                if(submitted == true){
                    submitted1 = true;

                    // If a successful submission occurred, hide the keyboard
                    InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                    // Push user info data to the DB
                    ContentValues myCV = new ContentValues();

                    // Get the account information and add it to the DataBase
                    myCV.put(InfoProvider.TODO_TABLE_COL_FIRST_NAME, firstName);
                    myCV.put(InfoProvider.TODO_TABLE_COL_MIDDLE_NAME, middleName);
                    myCV.put(InfoProvider.TODO_TABLE_COL_LAST_NAME, lastName);
                    myCV.put(InfoProvider.TODO_TABLE_COL_EMAIL, eMail);
                    myCV.put(InfoProvider.TODO_TABLE_COL_PHONE_NUMBER, phoneNumber);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ADDRESS, address);
                    myCV.put(InfoProvider.TODO_TABLE_COL_CITY, city);
                    myCV.put(InfoProvider.TODO_TABLE_COL_STATE, state);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ZIPCODE, zipCode);
                    myCV.put(InfoProvider.TODO_TABLE_COL_EMERGENCY_NAME, emergencyName);
                    myCV.put(InfoProvider.TODO_TABLE_COL_EMERGENCY_NUMBER, emergencyNumber);
                    myCV.put(InfoProvider.TODO_TABLE_COL_EMERGENCY_ADDRESS, emergencyAddress);
                    myCV.put(InfoProvider.TODO_TABLE_COL_HIGHSCHOOL, highSchool);
                    myCV.put(InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_LOCATION, highSchoolLocation);
                    myCV.put(InfoProvider.TODO_TABLE_COL_BIRTH_MONTH, monthSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_BIRTH_DAY, daySelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_BIRTH_YEAR, yearSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_EMERGENCY_RELATION, relationSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_HIGHSCHOOL_GPA, highGPASelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ACT_SCORE, actSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_SAT_SCORE, satSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_CLASS, classSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_COLLEGE_GPA, collegeGPASelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_MAJOR, majorSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_COLLEGE, collegeSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_SORORITY_ONE, firstPrefSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_SORORITY_TWO, secondPrefSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_SORORITY_THREE, thirdPrefSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ACTIVITY_ONE, activityOneSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ACTIVITY_TWO, activityTwoSelection);
                    myCV.put(InfoProvider.TODO_TABLE_COL_ACTIVITY_THREE, activityThreeSelection);

                    // Perform the insert function using the ContentProvider
                    getContentResolver().insert(InfoProvider.CONTENT_URI, myCV);

                    Toast.makeText(getApplicationContext(), "Rush registration submitted!", Toast.LENGTH_LONG).show();
                    submitRegistration.setText("Thank you for your submission! If you have letters of recommendation, a resume, or verified community service hours please mail them to: 1 University of Arkansas Fayetteville, AR 72701");
                }
            }
        });
    }
}
