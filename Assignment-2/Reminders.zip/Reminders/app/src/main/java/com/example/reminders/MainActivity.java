package com.example.reminders;

import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {

    // Creates a broadcast receiver to notify the user of a connectivity change
    private BroadcastReceiver Receiver;

    // The title of the note entered
    private String noteNameEntered;

    // Variable for the name of the note
    private EditText noteName;

    // Variable for the button when a user creates a new note
    private Button NewNoteButton;

    // Variable for the button when a user deletes the last note created
    private Button DeleteNoteButton;

    // Boolean variable to notify when to delete an object
    private Boolean delete = false;

    // Declare an array list of type string to hold and display the notes in the ListView
    static ArrayList<String> arrayOfNotes = new ArrayList<>();

    // Creates a variable for the adapter for the ListView - a tool to help the ListView
    static ArrayAdapter<String> notesAdapter;

    // Create a variable for a list of notes
    private ListView listOfNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Saves the current list of notes
        Saver.saveFile(arrayOfNotes, this);

        // Sets up the broadcast receiver by using the BroadcastReceiver class
        Receiver = new BroadcastReceiver(){

            // Overrides the onReceive function to display toast message when connectivity has changed
            @Override
            public void onReceive(Context context, Intent intent){
                if(Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())){
                    // Alerts the user with a toast message of connectivity change
                    Toast.makeText(context, "Connectivity changed!", Toast.LENGTH_SHORT).show();

                    // Save the current state of the note
                    saveNote();
                }
            }
        };

        // Sets the intent mode for the broadcast receiver (airplane mode)
        registerReceiver(Receiver, new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED));

        // Gets the field of the note name
        noteName = findViewById(R.id.noteNameField);

        // Set the list of notes by linking it to the field in the activity
        listOfNotes = (ListView) findViewById(R.id.notesList);

        // Assists in saving the names of the notes
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.reminders", Context.MODE_PRIVATE);
        HashSet<String> set = (HashSet<String>) sharedPreferences.getStringSet("notes", null);

        // Updates the list of notes if needed
        if(set != null){
            arrayOfNotes = new ArrayList(set);
        }

        // Saves the list of notes if needed
        Saver.saveFile(arrayOfNotes, this);

        // Loading the list of notes from previously saved data
        arrayOfNotes = Saver.readData(this);

        // Adapter for the notes in the listview and the array list of notes
        notesAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, arrayOfNotes);

        // Sets the adapter if a change was made to the list
        listOfNotes.setAdapter(notesAdapter);

        // Alert with toast messages about deleted or opening a selected note
        listOfNotes.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                // Deletes a note if the button was selected
                if(delete == true){

                    // If the list of notes is empty, do not activate the delete button
                    if(arrayOfNotes.isEmpty()){
                        // Sets the delete bool variable back to false if the list is empty
                        delete = false;
                        DeleteNoteButton.setTextColor(Color.BLACK);
                    }
                    // Displays a toast message to the user to let them know they are deleting a note
                    Toast.makeText(MainActivity.this, "Deleting: " + arrayOfNotes.get(position).toString(), Toast.LENGTH_SHORT).show();

                    // Saves the local position of the note entered
                    int index = position;

                    // Removes the note at the defined index from the list
                    arrayOfNotes.remove(index);

                    // Updates the array adapter of the change in the list of notes
                    notesAdapter.notifyDataSetChanged();

                    // Uses shared preferences and a hash set to permanently store the data
                    SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.reminders", Context.MODE_PRIVATE);
                    HashSet<String> set = new HashSet(MainActivity.arrayOfNotes);
                    sharedPreferences.edit().putStringSet("notes", set).apply();

                    // Saves the list of notes
                    saveNote();

                    // Sets the delete bool variable back to false when a delete has been performed
                    delete = false;
                    DeleteNoteButton.setTextColor(Color.BLACK);
                }
                // Else, open the note selected
                else{
                    // Displays a toast message to the user on which note they are opening
                    Toast.makeText(MainActivity.this, "Opening: " + arrayOfNotes.get(position).toString(), Toast.LENGTH_SHORT).show();

                    // Opens the new activity that contains the note data
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                    // Saves the ID of the note so the right activity will be opened
                    intent.putExtra("noteID", position);

                    // Launches the new activity
                    startActivity(intent);
                }
            }
        });

        // Sets the button for deleting note and listens for when it is pressed
        DeleteNoteButton = (Button) findViewById(R.id.deleteNoteBtn);
        DeleteNoteButton.setOnClickListener(new View.OnClickListener(){

            // When the button is pressed, delete the note that is selected
            @Override
            public void onClick(View v){
                // If the list is empty, do not activate the delete button (nothing to delete)
                if(arrayOfNotes.isEmpty()){
                    // Sets the delete bool variable back to false if the list is empty
                    delete = false;
                    DeleteNoteButton.setTextColor(Color.BLACK);
                }

                // Else, activate the delete button
                else{
                    // If delete is already activated, deactivate it
                    if(delete == true){
                        DeleteNoteButton.setTextColor(Color.BLACK);
                        delete = false;
                    }

                    // Sets the text of the delete button to active with WHITE
                    DeleteNoteButton.setTextColor(Color.WHITE);
                    delete = true;

                    // Informs the user that they need to click on a note to delete it
                    Toast.makeText(MainActivity.this, "Select a note to remove", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Sets the button for creating a new note and listens for when it is pressed
        NewNoteButton = (Button) findViewById(R.id.newNoteBtn);
        NewNoteButton.setOnClickListener(new View.OnClickListener(){
            // When the button is pressed, call the function to open up the new note in a new activity
            @Override
            public void onClick(View v){
                // Calls a function on what to do when a new note is opened
                openNewNote();
            }
        });
    }

    // Method to save new list of notes (used after deleting)
    public void saveNote(){
        Saver.saveFile(arrayOfNotes, this);
    }

    public void openNewNote(){
        // If a new note is opened, reset the delete button
        delete = false;
        DeleteNoteButton.setTextColor(Color.BLACK);

        // Gets the name of the note and adds it to the list
        noteNameEntered = noteName.getText().toString();

        // Reset the name of the note after it is used
        noteName.setText("");

        // Save the list of notes
        Saver.saveFile(arrayOfNotes, this);

        // If no note name was entered, make it a default note name
        if(noteNameEntered.length() == 0){
            noteNameEntered = "Untitled";
        }
        // Add the name of the note to the list
        arrayOfNotes.add(noteNameEntered);

        // Save the name of the note on the list to a file
        Saver.saveFile(arrayOfNotes, this);

        // Update the adapter with the new note
        notesAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, arrayOfNotes);
        listOfNotes.setAdapter(notesAdapter);

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.reminders", Context.MODE_PRIVATE);
        HashSet<String> set = new HashSet(MainActivity.arrayOfNotes);
        sharedPreferences.edit().putStringSet("notes", set).apply();
    }
}
