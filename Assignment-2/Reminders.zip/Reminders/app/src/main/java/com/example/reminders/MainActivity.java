package com.example.reminders;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    // Variable to determine if the delete button was pressed
    private Boolean delete = false;

    // Creates a broadcast receiver variable to notify the user of a connectivity change
    private BroadcastReceiver Receiver;

    // Variable for the button when a user creates a new note
    private Button NewNoteButton;

    // Variable for the button when a user deletes the last note created
    private Button DeleteNoteButton;

    // Declare an array list of type string to hold and display the title of the notes in the ListView
    static ArrayList<String> arrayOfNotes = new ArrayList<>();

    // Declare an array list of type string to hold and display the ID of the notes
    static ArrayList<String> arrayOfID = new ArrayList<>();

    // Creates a variable for the adapter for the ListView - a tool to help the ListView
    static ArrayAdapter<String> notesAdapter;

    // Create a ListView variable to hold the list of notes from the ArrayList
    static ListView listOfNotes;

    // Set the projection for the columns to be returned for the DB
    static String [] singleNote = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_TITLE,
            ToDoProvider.TODO_TABLE_COL_CONTENT,
            ToDoProvider.TODO_TABLE_COL_COMPLETED,
            ToDoProvider.TODO_TABLE_COL_DATE,
            ToDoProvider.TODO_TABLE_COL_TIME
    };

    // Override onCreate for initializations
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        delete = false;
        // Sets up the broadcast receiver by using the BroadcastReceiver class
        Receiver = new BroadcastReceiver(){

            // Overrides the onReceive function to display toast message when connectivity has changed
            @Override
            public void onReceive(Context context, Intent intent){
                if(Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())){

                    // Alerts the user with a toast message of connectivity change
                    Toast.makeText(context, "Connectivity changed!", Toast.LENGTH_SHORT).show();
                }
            }
        };

        // Sets the intent mode for the broadcast receiver (airplane mode)
        registerReceiver(Receiver, new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED));

        // Set the list of notes by linking it to the field in the activity
        listOfNotes = (ListView) findViewById(R.id.notesList);

        // Adapter for the notes in the ListView and the array list of notes
        notesAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, arrayOfNotes);

        // Sets the adapter if a change was made to the list
        listOfNotes.setAdapter(notesAdapter);

        // Alert with toast messages about deleting or opening a note
        listOfNotes.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                // If the user has selected to delete a note then allow them to click on which note they wish to delete
                if(delete == true){
                    delete = false;

                    // Get the value of the "true" ID
                    int ID = Integer.valueOf(arrayOfID.get(position));

                    // Subtract the "true" ID by '1' because it is out of bounds
                    ID = ID - 1;

                    //Perform the query of the DB, with ID Descending
                    Cursor myCursor = getContentResolver().query(ToDoProvider.CONTENT_URI, singleNote,null,null,null);

                    // Checks to see if there is data in the DB
                    if(myCursor != null & myCursor.getCount() > 0){

                        // Move the cursor to the row of the selected item
                        myCursor.moveToPosition(ID);

                        // Get the note title(column 1) of the selected note
                        //String newestTitle = myCursor.getString(1);

                        // Update the value of the "true" ID
                        ID = ID + 1;

                        // Attempts to delete the latest note in the DB
                        int didWork = getContentResolver().delete(Uri.parse(ToDoProvider.CONTENT_URI + "/" + ID), null, null);

                        //If deleted, didWork returns the number of rows deleted (should be 1)
                        if(didWork == 1){
                            //If it didWork, then create a Toast Message saying which note was deleted
                            Toast.makeText(getApplicationContext(), "Deleted Note", Toast.LENGTH_LONG).show();
                        }
                    }
                    else{
                        delete = false;
                        Toast.makeText(getApplicationContext(), "No Note to delete!", Toast.LENGTH_LONG).show();
                    }

                    // Check if the ListView still has values in it
                    if(!arrayOfNotes.isEmpty()){

                        //Delete the selected note and its ID
                        arrayOfNotes.remove(position);
                        arrayOfID.remove(position);

                        // Update the adapter for the ListView
                        notesAdapter = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1, arrayOfNotes);
                        listOfNotes.setAdapter(notesAdapter);
                    }
                    DeleteNoteButton.setTextColor(Color.BLACK);
                }

                // Else, the user wishes to open the note they selected
                else{
                    // Displays a toast message to the user on which note they are opening
                    Toast.makeText(MainActivity.this, "Opening: " + arrayOfNotes.get(position), Toast.LENGTH_SHORT).show();

                    // Get the "true" ID of the row that was clicked
                    int ID = Integer.valueOf(arrayOfID.get(position));

                    // Opens the new activity that contains the note data
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                    // Passes the selected note ID/row/status to the new activity
                    intent.putExtra("newNote", false);
                    intent.putExtra("row", position);
                    intent.putExtra("noteID", ID);

                    // Launches the new activity
                    startActivity(intent);
                }
            }
        });

        // Sets the button for deleting note and listens for when it is pressed
        DeleteNoteButton = (Button) findViewById(R.id.deleteNoteBtn);
        DeleteNoteButton.setOnClickListener(new View.OnClickListener(){

            // When the button is pressed, delete the top note
            @Override
            public void onClick(View v){

                if(delete == true || arrayOfNotes.isEmpty()){
                    Toast.makeText(getApplicationContext(), "No Note to delete!", Toast.LENGTH_LONG).show();
                    DeleteNoteButton.setTextColor(Color.BLACK);
                    delete = false;
                }
                else{
                    // Alerts the user with a toast message to select an item from the ListView to delete
                    Toast.makeText(MainActivity.this, "Select a Note to delete", Toast.LENGTH_SHORT).show();

                    // Sets the delete button text color to white so they are aware it has been selected
                    DeleteNoteButton.setTextColor(Color.WHITE);

                    // Sets the Boolean variable value for the delete button to true
                    delete = true;
                }

                // Calls a function that handles deleting the note
                //deleteNote();
            }
        });

        // Sets the button for creating a new note and listens for when it is pressed
        NewNoteButton = (Button) findViewById(R.id.newNoteBtn);
        NewNoteButton.setOnClickListener(new View.OnClickListener(){

            // When the button is pressed, open up the new note in a new activity
            @Override
            public void onClick(View v){

                // Calls a function on what to do when a new note is opened
                openNewNote();
            }
        });
    }

    // Overridden onResume function to update the ListView when returning to the MainActivity
    @Override
    protected void onResume(){
        super.onResume();
        delete = false;
        // Loads all of the updated values on the array list after resuming the activity
        loadList();

    }

    // Function that loads the updated list of notes to the ListView
    public void loadList(){

        // Clears the array lists so the most up-to-date data can be loaded into it
        arrayOfID.clear();
        arrayOfNotes.clear();

        // Performs a query to get all rows in the DB
        Cursor myCursor = getContentResolver().query(ToDoProvider.CONTENT_URI, singleNote,null,null, null);

        // Checks to see if there is data in the DB
        if(myCursor != null & myCursor.getCount() > 0){

            // Iterates through each row of the DB and sets the title back to the ListView after a reset, and updated the "true" ID
            for(int i = 0; i <  myCursor.getCount(); i++){

                // Creates a StringBuilder to hold the data pulled from the DB
                StringBuilder stringBuilder1 = new StringBuilder("");
                StringBuilder stringBuilder2 = new StringBuilder("");

                // Move the cursor to the next row
                myCursor.moveToNext();

                // Gets the value from columns 0 and 1 of the row in the DB which is the notes ID and title
                stringBuilder1.append(myCursor.getString(0));
                stringBuilder2.append(myCursor.getString(1));

                // Adds the notes title back to the ListView and ID back to the ArrayList
                arrayOfID.add(stringBuilder1.toString());
                arrayOfNotes.add(stringBuilder2.toString());

                // Updates the adapter so the changes are reflected on the ListView
                notesAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, arrayOfNotes);
                listOfNotes.setAdapter(notesAdapter);
            }
        }
    }

    // Function that handles deleting the top note in the ListView
    public void deleteNote(){

        // Check if the ListView still has values in it
        if(!arrayOfNotes.isEmpty()){
            //Delete the first note and its ID
            arrayOfNotes.remove(0);
            arrayOfID.remove(0);

            // Update the adapter for the ListView
            notesAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, arrayOfNotes);
            listOfNotes.setAdapter(notesAdapter);
        }

        //Perform the query of the DB, with ID Descending
        Cursor myCursor = getContentResolver().query(ToDoProvider.CONTENT_URI, singleNote,null,null,"_ID DESC");

        // Checks to see if there is data in the DB
        if(myCursor != null & myCursor.getCount() > 0){

            // Move the cursor to the top-most row
            myCursor.moveToLast();

            // Get the note ID (int) of the latest note (column 0)
            int newestId = myCursor.getInt(0);

            // Get the note title (string) of the latest note (column 1)
            String newestTitle = myCursor.getString(1);

            // Attempts to delete the latest note in the DB
            int didWork = getContentResolver().delete(Uri.parse(ToDoProvider.CONTENT_URI + "/" + newestId), null, null);

            //If deleted, didWork returns the number of rows deleted (should be 1)
            if (didWork == 1){
                //If it didWork, then create a Toast Message saying which note was deleted
                Toast.makeText(getApplicationContext(), "Deleted Note " + newestTitle, Toast.LENGTH_LONG).show();
            }
        }
        else{
            Toast.makeText(getApplicationContext(), "No Note to delete!", Toast.LENGTH_LONG).show();
        }

    }

    // Function that handles creating and opening a new note
    public void openNewNote(){
        delete = false;
        // Opens the new activity that contains the note data
        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

        // Passes a boolean value to the new activity to let it know that its a new note
        intent.putExtra("newNote", true);

        // Launches the new activity
        startActivity(intent);

    }
}
