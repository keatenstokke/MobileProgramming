package com.example.reminders;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import java.util.HashSet;
import static com.example.reminders.MainActivity.arrayOfNotes;

public class MainActivity2 extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Create a variable for the edit text field for the title of the note
        EditText noteTitle = (EditText) findViewById(R.id.noteTitleField);

        // Get the noteID and its title from the activities intent
        Intent intent = getIntent();
        final int noteID = intent.getIntExtra("noteID", -1);

        if(noteID != -1){
            noteTitle.setText(arrayOfNotes.get(noteID));
        }

        // Create a text change listener to save when new data is written into the edit text field
        noteTitle.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after){

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count){
                // Save the value typed into the edit text field into the array of notes
                MainActivity.arrayOfNotes.set(noteID, String.valueOf(s));

                // Update the adapter so that the change is reflected
                MainActivity.notesAdapter.notifyDataSetChanged();

                // Use shared preferences and a hash set to save the data
                SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.reminders", Context.MODE_PRIVATE);
                HashSet<String> set = new HashSet(MainActivity.arrayOfNotes);
                sharedPreferences.edit().putStringSet("notes", set).apply();
            }

            @Override
            public void afterTextChanged(Editable s){

            }
        });
    }

    // Method to save new list of notes (used after deleting)
    public void saveNote(){
        Saver2.saveFile2(arrayOfNotes, this);
    }
}
