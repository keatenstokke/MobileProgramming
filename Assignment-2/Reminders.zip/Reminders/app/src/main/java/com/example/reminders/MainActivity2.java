package com.example.reminders;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import static com.example.reminders.MainActivity.arrayOfNotes;
import static com.example.reminders.MainActivity.arrayOfID;
import static com.example.reminders.MainActivity.notesAdapter;
import static com.example.reminders.MainActivity.listOfNotes;

public class MainActivity2 extends AppCompatActivity{

    // Creates a button variable for the save function
    private Button saveNoteButton;

    // Set the projection for the columns to be returned for the DB
    String [] singleNote = new String[]{
            ToDoProvider.TODO_TABLE_COL_ID,
            ToDoProvider.TODO_TABLE_COL_TITLE,
            ToDoProvider.TODO_TABLE_COL_CONTENT,
            ToDoProvider.TODO_TABLE_COL_COMPLETED
    };

    // String that holds the value of the notes title from the EditText field
    private String title;

    // Create a variable for the EditText field for the title of the note
    private EditText noteTitle;

    // Create a variable for the EditText field for the info of the note
    private EditText noteInfo;

    // String that holds the value of the notes info from the EditText field
    private String info;

    // Create variables for the intent-extra's sent from the MainActivity
    private int rowID;
    private int row;

    // Status if the note opened was a new note or not
    private boolean status = false;

    // Variables to handle the switch button so the user can mark if the note is completed
    private Switch complete;
    private String done;

    // Override onCreate for initializations
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Get the passed intents from the MainActivity
        Intent intent = getIntent();

        // Passed intent value that lets the user know if it is a new note or not
        final Boolean noteStatus = intent.getBooleanExtra("newNote", true);

        // Passed intent values that enables this activity to identify which note on which row was clicked
        row = intent.getIntExtra("row", -1);
        rowID = intent.getIntExtra("noteID", -1);

        // Link the variables with their fields
        noteInfo = (EditText) findViewById(R.id.noteInfoField);
        noteTitle = (EditText) findViewById(R.id.noteTitleField);
        complete = (Switch) findViewById(R.id.noteComplete);
        saveNoteButton = (Button) findViewById(R.id.saveBtn);

        // Saves the status of the note if it is new or not
        status = noteStatus;

        // If a note was clicked and it already exists, go to a function to load the data from the database to the new activities view
        if(status == false){
            loadNoteInfo();
        }

        // Detects if the save button was pressed and goes to the saveNoteInfo function
        saveNoteButton.setOnClickListener(new View.OnClickListener(){

            // When the button is pressed, delete the top note
            @Override
            public void onClick(View v){
                // Calls a function that handles saving the notes data
                saveNoteInfo();
            }
        });

    }

    // If an existing note was clicked, load its data to the activities view
    public void loadNoteInfo(){
        // Query to the row that was clicked on where the clicked note exists
        Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, MainActivity.singleNote, null,null, null);

        // Scan through the items in the DB and set the notes title/ID/completed values to the activities view
        if(cursor != null && cursor.getCount() > 0){
            // Move the cursor to the corresponding row
            cursor.moveToPosition(rowID-1);
            // Set the notes title/info/completed values based on what was saved in the DB
            noteTitle.setText(cursor.getString(1));
            noteInfo.setText(cursor.getString(2));
            done = cursor.getString(3);

            // If the string is set to true, set the completed switch to ON
            if(done.equals("true")){
                complete.setChecked(true);
            }
            // Else set the completed switch to OFF
            else{
                complete.setChecked(false);
            }
        }
    }

    // Function for when the save button is pressed so the notes title/ID/Info/completed can be saved
    public void saveNoteInfo(){
        // If the note saved was a NEW note - insert the notes information into the DB
        if(status == true){
            // If no note title was entered, give it a default name
            if(noteTitle.getText().toString().length() == 0){
                title = "Untitled Note";
            }
            // Else set the note title to the entered value
            else{
                title = noteTitle.getText().toString();
            }

            // If no note info was entered, set it to empty
            if(noteInfo.getText().toString().length() == 0){
                info = "";
            }
            // Else set the note info to the entered value
            else{
                info = noteInfo.getText().toString();
            }

            // Check to see if the note was marked as completed
            status = complete.isChecked();
            if(status == true){
                done = "true";
            }
            // Else mark the note as uncompleted
            else{
                done = "false";
            }

            // Create a ContentValues object
            ContentValues myCV = new ContentValues();

            // Add the note title/info/completed to the ContentValue
            myCV.put(ToDoProvider.TODO_TABLE_COL_TITLE, title);
            myCV.put(ToDoProvider.TODO_TABLE_COL_CONTENT, info);
            myCV.put(ToDoProvider.TODO_TABLE_COL_COMPLETED, done);

            // Perform the insert function using the ContentProvider
            getContentResolver().insert(ToDoProvider.CONTENT_URI, myCV);

            // Perform a query to get all rows in the DB
            Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, singleNote,null,null,null);

            // Scan through the items and set the notes title and ID in their array lists
            if(cursor != null && cursor.getCount() > 0){
                if(cursor.moveToLast()){
                    // Add the "true" note ID to the ArrayList
                    arrayOfID.add(cursor.getString(0));

                    // Add the note title to the ArrayList
                    arrayOfNotes.add(cursor.getString(1));
                }
            }
            // Some error happened and there is nothing in the DB
            else{
                arrayOfNotes.add("ERROR - FIXME!");
            }

            // Update the adapter with the new notes title in the ListView
            notesAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, arrayOfNotes);
            listOfNotes.setAdapter(notesAdapter);
        }
        // Else the note saved was NOT a new note - update the existing row in the DB
        else{
            // If no note title was entered, give it a default name
            if(noteTitle.getText().toString().length() == 0){
                title = "Untitled Note";
            }
            // Else set the note title to the entered value
            else{
                title = noteTitle.getText().toString();
            }

            // If no note info was entered, set it to empty
            if(noteInfo.getText().toString().length() == 0){
                info = "";
            }
            // Else set the note info to the entered value
            else{
                info = noteInfo.getText().toString();
            }

            // Check to see if the note was marked as completed
            status = complete.isChecked();
            if(status == true){
                done = "true";
            }
            // Else mark the note as uncompleted
            else{
                done = "false";
            }

            // Create a ContentValues object
            ContentValues myCV = new ContentValues();

            // Add the note title/info/completed to the ContentValue
            myCV.put(ToDoProvider.TODO_TABLE_COL_TITLE, title);
            myCV.put(ToDoProvider.TODO_TABLE_COL_CONTENT, info);
            myCV.put(ToDoProvider.TODO_TABLE_COL_COMPLETED, done);

            // Perform a query to get all rows in the DB
            Cursor cursor = getContentResolver().query(ToDoProvider.CONTENT_URI, singleNote,null,null,null);

            // Scan through the items and update the notes title/ID/completed in the DB
            if(cursor != null && cursor.getCount() > 0){
                getContentResolver().update(Uri.parse(ToDoProvider.CONTENT_URI + "/" + rowID), myCV, null, null);
            }
        }

        // Alerts the user that their note data was saved
        Toast.makeText(MainActivity2.this, "Note Saved", Toast.LENGTH_SHORT).show();

        // Go back to the MainActivity after saving
        finish();
    }

}
